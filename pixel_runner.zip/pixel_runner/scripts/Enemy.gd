@tool
extends CharacterBody2D

enum Kind { ARCHER_GUARD, PIXEL_STUDIO_MOB, FLYING_EYE, GOBLIN, MUSHROOM, SKELETON, STAGE_BOSS }

@export var kind: Kind = Kind.PIXEL_STUDIO_MOB:
	set(value):
		kind = value
		if is_inside_tree():
			_setup_visual()

@export var drop_height := 550.0

@onready var anim: AnimatedSprite2D = $AnimatedSprite2D
@onready var hit_vfx: CPUParticles2D = get_node_or_null("HitVFX")

var hp := 60.0
var dead := false
var is_stage_boss := false
var attack_timer := 1.5
var flying_attacking := true
var flying_attack_cooldown := 2.5
var flying_attack_speed := 520.0
var flying_attack_damage := 18.0
var flying_attack_direction := Vector2.ZERO
var flying_attack_duration := 0.8

const ANIMATIONS = ["boss_eye", "boss_goblin", "boss_mushroom", "boss_skeleton"]

func _ready():
	add_to_group("enemy")
	_setup_frames()
	_setup_visual()

	if Engine.is_editor_hint():
		return

	if kind == Kind.ARCHER_GUARD:
		hp = 55 * GameConfig.power_scale
	elif kind == Kind.PIXEL_STUDIO_MOB:
		hp = 75 * GameConfig.power_scale
	elif kind == Kind.STAGE_BOSS:
		hp = 100 * GameConfig.power_scale
		scale = Vector2.ONE * 1.6
	else:
		hp = 85 * GameConfig.power_scale
		
	if kind not in [Kind.ARCHER_GUARD, Kind.FLYING_EYE]:
		global_position.y -= drop_height

func _setup_frames():
	var frames = anim.sprite_frames
	if frames == null:
		frames = SpriteFrames.new()
		anim.sprite_frames = frames

	_add_grid(frames, "archer_idle", "res://assets/Huntress 2/Sprites/Character/Idle.png", 10, 8)
	_add_grid(frames, "archer_shoot", "res://assets/Huntress 2/Sprites/Character/Attack.png", 6, 12)
	_add_grid(frames, "boss_eye", "res://assets/bosses/boss_eye.png", 6, 10)
	_add_grid(frames, "boss_goblin", "res://assets/bosses/boss_goblin.png", 12, 12)
	_add_grid(frames, "boss_mushroom", "res://assets/bosses/boss_mushroom.png", 11, 11)
	_add_grid(frames, "boss_skeleton", "res://assets/bosses/boss_skeleton.png", 6, 10)

	if not frames.has_animation("pixel_studio_walk"):
		frames.add_animation("pixel_studio_walk")
		frames.set_animation_speed("pixel_studio_walk", 10)
		frames.set_animation_loop("pixel_studio_walk", true)
		for i in range(8):
			var path = "res://assets/pixel_mob/frame_%d.png" % i
			if ResourceLoader.exists(path):
				frames.add_frame("pixel_studio_walk", load(path))

func _add_grid(frames, name, path, columns, fps):
	if frames.has_animation(name) or not ResourceLoader.exists(path):
		return
	var texture = load(path)
	frames.add_animation(name)
	frames.set_animation_speed(name, fps)
	frames.set_animation_loop(name, true)
	var width = texture.get_width() / columns
	for i in range(columns):
		var frame = AtlasTexture.new()
		frame.atlas = texture
		frame.region = Rect2(i * width, 0, width, texture.get_height())
		frames.add_frame(name, frame)

func _setup_visual():
	if not is_instance_valid(anim) or not anim.sprite_frames:
		return

	anim.position = Vector2.ZERO
	anim.scale = Vector2.ONE

	match kind:
		Kind.ARCHER_GUARD:
			anim.play("archer_idle")
			anim.scale = Vector2(1.5, 1.5)
			anim.position.y = -14
		Kind.PIXEL_STUDIO_MOB:
			anim.play("pixel_studio_walk")
		Kind.FLYING_EYE:
			anim.play("boss_eye")
		Kind.GOBLIN:
			anim.play("boss_goblin")
		Kind.MUSHROOM:
			anim.play("boss_mushroom")
		Kind.SKELETON:
			anim.play("boss_skeleton")
		Kind.STAGE_BOSS:
			anim.play(ANIMATIONS[(GameConfig.stage_num - 1) % ANIMATIONS.size()])
			anim.scale = Vector2.ONE * 1.6

func _physics_process(delta):
	if Engine.is_editor_hint() or dead:
		return

	var hero = get_tree().get_first_node_in_group("hero")
	if not is_instance_valid(hero):
		return

	var direction = hero.global_position - global_position
	anim.flip_h = direction.x < 0

	if kind == Kind.ARCHER_GUARD:
		_archer_attack(direction, delta)
		return

	elif kind == Kind.FLYING_EYE:
		_flying_eye_attack(hero, direction, delta)
		return


	if not is_on_floor():
		velocity.y += 1400 * delta
	else:
		velocity.y = 0

	velocity.x = signf(direction.x) * _move_speed()
	move_and_slide()

	if absf(direction.x) < 62 and absf(direction.y) < 78:
		attack_timer -= delta
		if attack_timer <= 0:
			attack_timer = 1.15
			hero.hit(12 * GameConfig.power_scale)

func _move_speed():
	match kind:
		Kind.GOBLIN: return 185.0
		Kind.MUSHROOM: return 115.0
		Kind.SKELETON: return 135.0
		Kind.STAGE_BOSS: return 100.0
		_: return 150.0

func _archer_attack(direction, delta):
	attack_timer -= delta
	if attack_timer > 0 or absf(direction.x) > 1150:
		return

	attack_timer = 1.8
	anim.play("archer_shoot")
	GameConfig.play_sfx("shoot", 0.08)

	var main = get_tree().current_scene
	if main and main.has_method("spawn_arrow"):
		main.spawn_arrow(global_position + Vector2(0, -14), direction.normalized(), 580, 14 * GameConfig.power_scale, false)

	await get_tree().create_timer(0.45).timeout
	if not dead:
		anim.play("archer_idle")
	
	

func _flying_eye_attack(hero, direction: Vector2, delta: float):
	flying_attack_cooldown -= delta
	
	if flying_attacking:
		flying_attack_duration -= delta
		velocity = flying_attack_direction * flying_attack_speed
		move_and_slide()

		if global_position.distance_to(hero.global_position) < 48:
			hero.hit(flying_attack_damage * GameConfig.power_scale)
			flying_attacking = false
			flying_attack_cooldown = 2.5
			velocity = Vector2.ZERO
			return
		if flying_attack_duration <= 0:
			flying_attacking = false
			flying_attack_cooldown = 2.5
			velocity = Vector2.ZERO

		return
	var target_position = hero.global_position + Vector2(0, -100)
	var distance = global_position.distance_to(hero.global_position)

	velocity = (target_position - global_position).normalized() * 145
	move_and_slide()

	if flying_attack_cooldown <= 0 and distance < 550:
		flying_attacking = true
		flying_attack_duration = 0.8
		flying_attack_direction = direction.normalized()
		velocity = flying_attack_direction * flying_attack_speed

		GameConfig.play_sfx("shoot", 0.08)



		velocity = (target_position - global_position).normalized() * 145
		move_and_slide()

		if flying_attack_cooldown <= 0 and distance < 550:
				flying_attacking = true
				flying_attack_duration = 0.65
				flying_attack_direction = direction.normalized()
				GameConfig.play_sfx("shoot", 0.08)
func hit(damage):
	if dead:
		return

	hp -= damage
	GameConfig.play_sfx("hit")
	if is_instance_valid(hit_vfx):
		hit_vfx.restart()

	anim.modulate = Color(2.5, 2.5, 2.5)
	create_tween().tween_property(anim, "modulate", Color.WHITE, 0.1)

	if hp <= 0:
		_die()

func _die():
	if dead:
		return

	dead = true
	GameConfig.kills += 1
	GameConfig.score += 1000 if kind == Kind.STAGE_BOSS else 100
	GameConfig.play_sfx("enemy_die")

	var main = get_tree().current_scene
	if is_instance_valid(main):
		if main.has_method("shake_camera"):
			main.shake_camera(7 if kind == Kind.STAGE_BOSS else 3)
		if is_stage_boss and main.has_method("boss_cleared"):
			main.boss_cleared()

	queue_free()
