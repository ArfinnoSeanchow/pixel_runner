extends Control
func _ready() -> void:
	size = Vector2(36, 36)
func _process(_delta: float) -> void:
	position = get_viewport().get_mouse_position() - Vector2(18, 18)
	queue_redraw()
func _draw() -> void:
	var wood := Color(0.78, 0.57, 0.31)
	var dark := Color(0.16, 0.10, 0.06)
	draw_circle(Vector2(18, 18), 13, Color(0.04, 0.06, 0.07, 0.18))
	draw_arc(Vector2(18, 18), 12, 0, TAU, 32, wood, 2.0)
	draw_line(Vector2(18, 2), Vector2(18, 10), dark, 2.0)
	draw_line(Vector2(18, 26), Vector2(18, 34), dark, 2.0)
	draw_line(Vector2(2, 18), Vector2(10, 18), dark, 2.0)
	draw_line(Vector2(26, 18), Vector2(34, 18), dark, 2.0)
	draw_circle(Vector2(18, 18), 2.5, wood)
