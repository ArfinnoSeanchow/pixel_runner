extends Node
enum Stage { GLACIAL, DARK_FOREST, CAVE }
const SAVE_PATH := "user://settings.cfg"
const CUSTOM_AUDIO_PATHS := {
	"bgm": "res://assets/audio/music.mp3",
	"shoot": "res://assets/audio/arrow_shoot.mp3",
	"sword": "res://assets/audio/sword.mp3",
	"pickup": "res://assets/audio/pickup.mp3",
	"hit": "res://assets/audio/hit_enemy.mp3",
	"enemy_die": "res://assets/audio/enemy_die.mp3",
	"hurt": "res://assets/audio/hero_hurt.mp3",
	"jump": "res://assets/audio/jump.mp3",
	"dash": "res://assets/audio/dash.mp3",
	"wave_up": "res://assets/audio/stage_transition.mp3",
	"game_over": "res://assets/audio/game_over.mp3",
	"click": "res://assets/audio/ui_click.mp3"
}
var stage: Stage = Stage.GLACIAL
var stage_num: int = 1
var wave_num: int = 1
var power_scale: float = 1.0
var kills: int = 0
var score: int = 0
var best_score: int = 0
var best_distance: int = 0
var best_kills: int = 0
var loadout: Array[int] = [0, 1]
var active_weapon: int = 0
var difficulty: int = 1
var coins: int = 0
var bounce_count: int = 0
var bounce_damage_bonus: float = 0.0
const WEAPONS := [
	{"name": "REPEATER", "damage": 17.0, "speed": 1050.0, "cooldown": 0.16},
	{"name": "SWORD", "damage": 48.0, "speed": 0.0, "cooldown": 0.48}
]
const DIFFICULTIES := [
	{"name": "MUDAH", "start": 4, "extra": 1, "interval": 0.55, "power": 0.9},
	{"name": "NORMAL", "start": 6, "extra": 2, "interval": 0.42, "power": 1.0},
	{"name": "SULIT", "start": 9, "extra": 3, "interval": 0.32, "power": 1.2}
]
var master_vol: float = 0.85
var bgm_vol: float = 0.55
var sfx_vol: float = 0.85
var screen_shake: bool = true
var _bgm_player: AudioStreamPlayer
var _sfx_cache: Dictionary = {}
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	load_settings()
	_init_audio_templates()
	start_bgm()
func reset() -> void:
	stage = Stage.GLACIAL
	stage_num = 1
	wave_num = 1
	power_scale = float(DIFFICULTIES[difficulty]["power"])
	kills = 0
	score = 0
	coins = 0
	bounce_count = 0
	bounce_damage_bonus = 0.0
	active_weapon = 0
func load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) == OK:
		master_vol = clampf(cfg.get_value("audio", "master_vol", 0.85), 0.0, 1.0)
		bgm_vol = clampf(cfg.get_value("audio", "bgm_vol", 0.55), 0.0, 1.0)
		sfx_vol = clampf(cfg.get_value("audio", "sfx_vol", 0.85), 0.0, 1.0)
		screen_shake = bool(cfg.get_value("gameplay", "screen_shake", true))
		best_score = int(cfg.get_value("records", "best_score", 0))
		best_distance = int(cfg.get_value("records", "best_distance", 0))
		best_kills = int(cfg.get_value("records", "best_kills", 0))
	apply_audio_settings()
func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("audio", "master_vol", master_vol)
	cfg.set_value("audio", "bgm_vol", bgm_vol)
	cfg.set_value("audio", "sfx_vol", sfx_vol)
	cfg.set_value("gameplay", "screen_shake", screen_shake)
	cfg.set_value("records", "best_score", best_score)
	cfg.set_value("records", "best_distance", best_distance)
	cfg.set_value("records", "best_kills", best_kills)
	cfg.save(SAVE_PATH)
	apply_audio_settings()
func apply_audio_settings() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(0.0001, master_vol)))
	AudioServer.set_bus_mute(0, master_vol <= 0.001)
	if _bgm_player:
		_bgm_player.volume_db = linear_to_db(maxf(0.0001, bgm_vol))
		_bgm_player.stream_paused = (bgm_vol <= 0.001)
func _init_audio_templates() -> void:
	for key in CUSTOM_AUDIO_PATHS:
		var path: String = CUSTOM_AUDIO_PATHS[key]
		if ResourceLoader.exists(path):
			_sfx_cache[key] = load(path)
	_bgm_player = AudioStreamPlayer.new()
	_bgm_player.process_mode = Node.PROCESS_MODE_ALWAYS
	if ResourceLoader.exists(CUSTOM_AUDIO_PATHS["bgm"]):
		_bgm_player.stream = load(CUSTOM_AUDIO_PATHS["bgm"])
	add_child(_bgm_player)
	apply_audio_settings()
func start_bgm() -> void:
	if _bgm_player and _bgm_player.stream and not _bgm_player.playing:
		_bgm_player.play()
func play_sfx(key: String, pitch_jitter: float = 0.06) -> void:
	if sfx_vol <= 0.001 or not _sfx_cache.has(key):
		return
	var p := AudioStreamPlayer.new()
	p.process_mode = Node.PROCESS_MODE_ALWAYS
	p.stream = _sfx_cache[key]
	p.volume_db = linear_to_db(sfx_vol)
	p.pitch_scale = randf_range(1.0 - pitch_jitter, 1.0 + pitch_jitter)
	add_child(p)
	p.finished.connect(p.queue_free)
	p.play()
func select_weapon(slot: int) -> void:
	if slot < 0 or slot > 1:
		return
	active_weapon = slot
func get_weapon_stats() -> Dictionary:
	var weapon_id: int = loadout[active_weapon]
	var stats: Dictionary = WEAPONS[weapon_id].duplicate(true)
	stats["damage"] = float(stats["damage"]) * (1.0 + bounce_damage_bonus)
	return stats
func gain_bounce_progress() -> void:
	bounce_count += 1
	bounce_damage_bonus = minf(0.40, bounce_count * 0.08)
	coins += 10
	score += 50
func update_records(distance: int) -> void:
	best_score = maxi(best_score, score)
	best_distance = maxi(best_distance, distance)
	best_kills = maxi(best_kills, kills)
	save_settings()
