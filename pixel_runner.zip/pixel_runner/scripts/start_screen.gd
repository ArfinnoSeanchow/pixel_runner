
extends Control

@onready var bg: TextureRect = $BG


func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().paused = false
	Engine.time_scale = 1.0
	GameConfig.start_bgm()
	_build_menu()


func _build_menu() -> void:
	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0, 0.45)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(shade)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var box := VBoxContainer.new()
	box.custom_minimum_size.x = 280
	box.add_theme_constant_override("separation", 12)
	center.add_child(box)
#title
	var title := Label.new()
	title.text = "Pixel Runner"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 58)
	box.add_child(title)

	var subtitle := Label.new()
	subtitle.text = "The PixelMan SIGNATURE"
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 12)
	box.add_child(subtitle)

	var space := Control.new()
	space.custom_minimum_size.y = 20
	box.add_child(space)

	var start := Button.new()
	start.text = "letss gooooo"
	start.custom_minimum_size.y = 48
	start.pressed.connect(_start_game)
	box.add_child(start)

	var settings := Button.new()
	settings.text = "settings"
	settings.custom_minimum_size.y = 42
	settings.pressed.connect(_show_settings)
	box.add_child(settings)


func _start_game() -> void:
	GameConfig.loadout = [0, 1]
	GameConfig.active_weapon = 0
	GameConfig.difficulty = 1
	GameConfig.reset()
	get_tree().change_scene_to_file("res://scenes/main.tscn")


func _show_settings() -> void:
	var dialog := AcceptDialog.new()
	dialog.title = "PENGATURAN"
	dialog.ok_button_text = "TUTUP"
	var content := VBoxContainer.new()
	dialog.add_child(content)

	_add_slider(content, "Volume", GameConfig.master_vol, func(v): GameConfig.master_vol = v)
	_add_slider(content, "Musik", GameConfig.bgm_vol, func(v): GameConfig.bgm_vol = v)
	_add_slider(content, "Efek Suara", GameConfig.sfx_vol, func(v): GameConfig.sfx_vol = v)

	add_child(dialog)
	dialog.popup_centered()


func _add_slider(parent: VBoxContainer, title: String, initial: float, changed: Callable) -> void:
	var label := Label.new()
	label.text = title
	parent.add_child(label)

	var slider := HSlider.new()
	slider.min_value = 0
	slider.max_value = 1
	slider.step = 0.05
	slider.value = initial
	slider.value_changed.connect(func(v):
		changed.call(v)
		GameConfig.save_settings()
	)
	parent.add_child(slider)
