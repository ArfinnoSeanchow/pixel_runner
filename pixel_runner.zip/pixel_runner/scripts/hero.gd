@tool
extends CharacterBody2D
signal hp_updated(now: float, top: float)
signal died
var hp: float = 120.0
var max_hp: float = 120.0
var dead: bool = false
var dir_x: float = 1.0
var cd: float = 0.0
var dash_time: float = 0.0
var dash_cooldown: float = 0.0
var respawn_invuln: float = 0.0
@onready var anim: AnimatedSprite2D = $AnimatedSprite2D
@onready var muzzle: Marker2D = $Muzzle
@onready var jump_vfx: CPUParticles2D = $JumpVFX
func _ready() -> void:
	add_to_group("hero")
	_build_frames()
	anim.play("walk" if Engine.is_editor_hint() else "idle")
func _build_frames() -> void:
	var sf := SpriteFrames.new()
	sf.remove_animation("default")
	var list := {
		"idle": ["res://assets/hero/idle.png", 8.0, true],
		"walk": ["res://assets/hero/walk.png", 10.0, true],
		"jump": ["res://assets/hero/jump.png", 10.0, false],
		"death": ["res://assets/hero/death.png", 8.0, false]
	}
	for k in list.keys():
		sf.add_animation(k)
		sf.set_animation_speed(k, list[k][1])
		sf.set_animation_loop(k, list[k][2])
		if ResourceLoader.exists(list[k][0]):
			var tex: Texture2D = load(list[k][0])
			var cols := maxi(1, int(tex.get_width() / 48))
			var fw := int(tex.get_width() / cols)
			var fh := tex.get_height()
			for i in range(cols):
				var at := AtlasTexture.new()
				at.atlas = tex
				at.region = Rect2(i * fw, 0, fw, fh)
				sf.add_frame(k, at)
	anim.sprite_frames = sf
func _physics_process(delta: float) -> void:
	if Engine.is_editor_hint() or dead:
		return
	if respawn_invuln > 0.0:
		respawn_invuln = maxf(0.0, respawn_invuln - delta)
		anim.modulate.a = 0.45 if int(respawn_invuln * 10.0) % 2 == 0 else 1.0
	else:
		anim.modulate.a = 1.0
	if not is_on_floor():
		velocity.y += 1550.0 * delta
	var move := Input.get_axis("move_left", "move_right")
	if dash_cooldown > 0.0:
		dash_cooldown -= delta
	if dash_time > 0.0:
		dash_time -= delta
	else:
		velocity.x = move * 370.0
	if Input.is_key_pressed(KEY_SHIFT) and dash_cooldown <= 0.0 and absf(move) > 0.1:
		dash_time = 0.16
		dash_cooldown = 0.85
		velocity.x = move * 1050.0
		GameConfig.play_sfx("dash")
	if move != 0.0:
		dir_x = signf(move)
		anim.flip_h = dir_x < 0.0
		muzzle.position.x = absf(muzzle.position.x) * dir_x
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = -670.0
		GameConfig.play_sfx("jump")
		if jump_vfx:
			jump_vfx.restart()
	move_and_slide()
	if not is_on_floor():
		anim.play("jump")
	elif absf(move) > 0.1:
		anim.play("walk")
	else:
		anim.play("idle")
	cd = maxf(0.0, cd - delta)
	if Input.is_action_just_pressed("weapon_one"):
		GameConfig.select_weapon(0)
	if Input.is_action_just_pressed("weapon_two"):
		GameConfig.select_weapon(1)
	var mouse_attack := Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)
	var key_attack := Input.is_action_pressed("attack")
	if (mouse_attack or key_attack) and cd <= 0.0:
		var aim_dir := Vector2(dir_x, 0.0)
		if mouse_attack:
			aim_dir = (get_global_mouse_position() - muzzle.global_position).normalized()
		if aim_dir.length_squared() < 0.001:
			aim_dir = Vector2(dir_x, 0.0)
		if absf(aim_dir.x) > 0.08:
			dir_x = signf(aim_dir.x)
		anim.flip_h = dir_x < 0.0
		muzzle.position.x = absf(muzzle.position.x) * dir_x
		_attack(aim_dir)
func _attack(aim_dir: Vector2) -> void:
	var recoil := create_tween()
	recoil.tween_property(anim, "position", Vector2(-7.0 * dir_x, -14.0), 0.04)
	recoil.tween_property(anim, "position", Vector2(0.0, -10.0), 0.08)
	var weapon_id: int = GameConfig.loadout[GameConfig.active_weapon]
	var weapon: Dictionary = GameConfig.get_weapon_stats()
	cd = float(weapon["cooldown"])
	if weapon_id == 1:
		GameConfig.play_sfx("sword")
		_show_sword_slash()
		for enemy in get_tree().get_nodes_in_group("enemy"):
			var diff: Vector2 = enemy.global_position - global_position
			var forward := diff.x * dir_x
			if forward >= -12.0 and forward <= 155.0 and absf(diff.y) <= 105.0:
				enemy.hit(float(weapon["damage"]))
	else:
		GameConfig.play_sfx("shoot")
		_show_muzzle_flash()
		var main := get_tree().current_scene
		if main and main.has_method("spawn_arrow"):
			main.spawn_arrow(muzzle.global_position, aim_dir, float(weapon["speed"]), float(weapon["damage"]), true)
func _show_sword_slash() -> void:
	var colors: Array[Color] = [
		Color(1.0, 0.24, 0.055, 0.95),
		Color(1.0, 0.62, 0.12, 0.9),
		Color(1.0, 0.94, 0.62, 0.95)
	]
	var widths: Array[float] = [15.0, 8.0, 3.0]
	for layer in range(3):
		var slash := Line2D.new()
		slash.width = widths[layer]
		slash.default_color = colors[layer]
		slash.z_index = 9 + layer
		slash.begin_cap_mode = Line2D.LINE_CAP_ROUND
		slash.end_cap_mode = Line2D.LINE_CAP_ROUND
		slash.position = Vector2(34.0 * dir_x, -18.0)
		slash.rotation = 0.0 if dir_x > 0.0 else PI
		for i in range(15):
			var angle := lerpf(-1.2, 1.2, float(i) / 14.0)
			slash.add_point(Vector2(cos(angle) * 88.0, sin(angle) * 88.0))
		add_child(slash)
		slash.scale = Vector2(0.48, 0.48)
		var slash_tween := create_tween().set_parallel(true)
		slash_tween.tween_property(slash, "scale", Vector2(1.22, 1.22), 0.19)
		slash_tween.tween_property(slash, "modulate:a", 0.0, 0.24)
		slash_tween.chain().tween_callback(slash.queue_free)
	var sparks := CPUParticles2D.new()
	sparks.position = Vector2(38.0 * dir_x, -22.0)
	sparks.z_index = 12
	sparks.amount = 26
	sparks.lifetime = 0.32
	sparks.one_shot = true
	sparks.explosiveness = 0.95
	sparks.direction = Vector2(dir_x, -0.15)
	sparks.spread = 72.0
	sparks.gravity = Vector2(0.0, 95.0)
	sparks.initial_velocity_min = 120.0
	sparks.initial_velocity_max = 310.0
	sparks.scale_amount_min = 2.0
	sparks.scale_amount_max = 5.0
	sparks.color = Color(1.0, 0.38, 0.07, 1.0)
	add_child(sparks)
	sparks.emitting = true
	var spark_tween := create_tween()
	spark_tween.tween_interval(0.38)
	spark_tween.tween_callback(sparks.queue_free)
func _show_muzzle_flash() -> void:
	var flash := Polygon2D.new()
	flash.polygon = PackedVector2Array([Vector2(0, -9), Vector2(27, 0), Vector2(0, 9), Vector2(-7, 0)])
	flash.color = Color(1.0, 0.84, 0.45, 0.95)
	flash.position = muzzle.position
	flash.z_index = 8
	add_child(flash)
	var tween := create_tween().set_parallel(true)
	tween.tween_property(flash, "scale", Vector2(0.25, 0.25), 0.1)
	tween.tween_property(flash, "modulate:a", 0.0, 0.1)
	tween.chain().tween_callback(flash.queue_free)
func heal(amount: float) -> void:
	if dead:
		return
	hp = minf(max_hp, hp + amount)
	hp_updated.emit(hp, max_hp)
func hit(dmg: float) -> void:
	if dead or respawn_invuln > 0.0:
		return
	hp = maxf(0.0, hp - dmg)
	hp_updated.emit(hp, max_hp)
	GameConfig.play_sfx("hurt")
	var main := get_tree().current_scene
	if main and main.has_method("shake_camera"):
		main.shake_camera(6.5)
	anim.modulate = Color(2.0, 0.4, 0.4)
	create_tween().tween_property(anim, "modulate", Color.WHITE, 0.14)
	if hp <= 0.0:
		dead = true
		anim.play("death")
		died.emit()
func bounce_back() -> void:
	dead = false
	respawn_invuln = 1.25
	hp = max_hp
	velocity = Vector2.ZERO
	anim.modulate = Color.WHITE
	anim.position = Vector2(0.0, -10.0)
	anim.play("idle")
	hp_updated.emit(hp, max_hp)
