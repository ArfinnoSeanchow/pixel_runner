extends Area2D
var direction: Vector2 = Vector2.RIGHT
var speed: float = 800.0
var damage: float = 20.0
var from_hero: bool = true
var life: float = 2.4
func _ready() -> void:
	rotation = direction.angle()
	if not from_hero:
		$Sprite2D.modulate = Color(1.0, 0.45, 0.45)
	body_entered.connect(_on_body)
func _physics_process(delta: float) -> void:
	position += direction * speed * delta
	life -= delta
	if life <= 0.0:
		queue_free()
func _on_body(body: Node) -> void:
	if from_hero and body.is_in_group("enemy") and body.has_method("hit"):
		body.hit(damage)
		queue_free()
	elif not from_hero and body.is_in_group("hero") and body.has_method("hit"):
		body.hit(damage)
		queue_free()
