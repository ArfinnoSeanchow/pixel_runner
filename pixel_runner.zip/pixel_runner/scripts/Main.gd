@tool
extends Node2D

@export var preview_stage: GameConfig.Stage = GameConfig.Stage.GLACIAL:
	set(value):
		preview_stage = value
		if is_inside_tree():
			_set_stage_bg(value)

@export var enemy_scene: PackedScene
@export var tower_scene: PackedScene
@export var arrow_scene: PackedScene

const GAME_OVER_SCENE = preload("res://scenes/ui/game_over_ui.tscn")
const WAVE_BANNER_SCENE = preload("res://scenes/ui/wave_banner_ui.tscn")
const MAX_ENEMIES = 6

@onready var hero: CharacterBody2D = $World/Hero
@onready var camera: Camera2D = $World/Camera2D
@onready var ground: StaticBody2D = $World/Ground
@onready var curtain: ColorRect = $HUD/CinemaCurtain
@onready var stage_text: Label = $HUD/CinemaCurtain/StageText
@onready var hp_bar: ProgressBar = $HUD/TopLeft/HPBar
@onready var distance_label: Label = $HUD/TopLeft/DistLabel
@onready var score_label: Label = $HUD/TopLeft/ScoreLabel

var wave_banner
var game_over
var pause_layer: CanvasLayer
var towers: Array[Node2D] = []
var wave_left := 0
var spawn_timer := 0.0
var next_wave_timer := 2.0
var next_tower_x := 2600.0
var next_boss_distance := 500
var boss_alive := false
var camera_shake := 0.0

func _ready():
	_set_stage_bg(preview_stage if Engine.is_editor_hint() else GameConfig.stage)
	if Engine.is_editor_hint():
		return

	GameConfig.reset()
	GameConfig.start_bgm()
	get_tree().paused = false
	Engine.time_scale = 1.0
	hero.add_to_group("hero")
	curtain.hide()
	$HUD/GameOver.hide()

	wave_banner = WAVE_BANNER_SCENE.instantiate()
	$HUD.add_child(wave_banner)
	game_over = GAME_OVER_SCENE.instantiate()
	$HUD.add_child(game_over)
	game_over.retry_requested.connect(_retry)
	game_over.menu_requested.connect(_menu)

	hero.hp_updated.connect(_update_hp)
	hero.died.connect(_on_hero_died)
	hp_bar.max_value = hero.max_hp
	hp_bar.value = hero.hp

	_make_tower(hero.position.x + 620)
	_make_tower(hero.position.x + 1420)
	_start_wave()
	_build_pause()

func _process(delta):
	if Engine.is_editor_hint():
		return

	camera.position = Vector2(hero.position.x + 340, 540) + _shake(delta)
	ground.position.x = snappedf(hero.position.x, 64)

	if hero.dead:
		return

	var distance = int(hero.position.x / 35)
	distance_label.text = "STAGE KE- %d  |  %dm" % [GameConfig.stage_num, distance]
	score_label.text = "SKOR %06d" % GameConfig.score

	_update_waves(delta)
	_update_towers()

	if hero.position.x + 1500 > next_tower_x:
		if randf() < 0.6:
			_make_tower(next_tower_x)
		next_tower_x += randf_range(1400, 1900)

	if distance >= next_boss_distance and not boss_alive:
		_spawn_boss()

func _unhandled_input(event):
	if Engine.is_editor_hint():
		return
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F7:
		var mode = DisplayServer.window_get_mode()
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if mode == DisplayServer.WINDOW_MODE_FULLSCREEN else DisplayServer.WINDOW_MODE_FULLSCREEN)
	if event.is_action_pressed("ui_cancel") and not hero.dead:
		_toggle_pause()

func _shake(delta):
	if not GameConfig.screen_shake:
		return Vector2.ZERO
	var offset = Vector2.ZERO
	if camera_shake > 0.1:
		offset = Vector2(randf_range(-camera_shake, camera_shake), randf_range(-camera_shake, camera_shake))
		camera_shake = lerpf(camera_shake, 0, delta * 12)
	return offset

func shake_camera(amount):
	camera_shake = maxf(camera_shake, amount)

func _update_hp(current, maximum):
	hp_bar.max_value = maximum
	hp_bar.value = current

func _start_wave():
	var settings = GameConfig.DIFFICULTIES[GameConfig.difficulty]
	wave_left = mini(int(settings["start"] + (GameConfig.wave_num - 1) * settings["extra"]), 15)
	spawn_timer = 1.0
	wave_banner.show_wave(GameConfig.wave_num, wave_left)

func _update_waves(delta):
	var settings = GameConfig.DIFFICULTIES[GameConfig.difficulty]
	for enemy in get_tree().get_nodes_in_group("enemy"):
		if not enemy.is_stage_boss and enemy.global_position.x < hero.global_position.x - 1100:
			enemy.queue_free()

	var alive = get_tree().get_nodes_in_group("enemy").size()
	if wave_left > 0:
		spawn_timer -= delta
		if spawn_timer <= 0 and alive < MAX_ENEMIES:
			if _spawn_enemy():
				wave_left -= 1
			spawn_timer = maxf(float(settings["interval"]), 0.9)
	elif alive == 0:
		next_wave_timer -= delta
		if next_wave_timer <= 0:
			GameConfig.wave_num += 1
			GameConfig.power_scale += 0.07 * float(settings["power"])
			hero.heal(8)
			GameConfig.play_sfx("wave_up")
			next_wave_timer = 2.0
			_start_wave()

func _spawn_enemy():
	if not enemy_scene:
		return false

	var enemy = enemy_scene.instantiate()
	enemy.kind = randi_range(0, 5)
	var x = hero.global_position.x + randf_range(820, 1180)

	if enemy.kind == 0:
		var tower = _nearest_tower(x)
		if tower == null:
			_make_tower(x)
			tower = towers.back() if not towers.is_empty() else null
		if tower == null:
			enemy.queue_free()
			return false
		enemy.position = Vector2(tower.position.x, tower.position.y - 55)
	else:
		enemy.position = Vector2(x, 845)

	$World.add_child(enemy)
	return true

func _make_tower(x):
	if not tower_scene:
		return
	var tower = tower_scene.instantiate()
	tower.position = Vector2(x, randf_range(805, 850))
	$World.add_child(tower)
	towers.append(tower)

func _nearest_tower(x):
	var closest = null
	var distance = 420.0
	for tower in towers:
		if is_instance_valid(tower) and absf(tower.position.x - x) < distance:
			closest = tower
			distance = absf(tower.position.x - x)
	return closest

func _update_towers():
	for i in range(towers.size() - 1, -1, -1):
		if not is_instance_valid(towers[i]) or towers[i].position.x < hero.position.x - 1400:
			if is_instance_valid(towers[i]):
				towers[i].queue_free()
			towers.remove_at(i)

func _spawn_boss():
	if not enemy_scene:
		return
	boss_alive = true
	_show_message("BOSS DATANGG HATI HATII")
	var boss = enemy_scene.instantiate()
	boss.kind = 6
	boss.is_stage_boss = true
	boss.position = Vector2(hero.position.x + 1150, 720)
	$World.add_child(boss)

func boss_cleared():
	boss_alive = false
	next_boss_distance += 500
	GameConfig.power_scale += 0.25
	if GameConfig.stage_num == 1:
		GameConfig.stage_num = 2
		GameConfig.stage = GameConfig.Stage.DARK_FOREST
		_set_stage_bg(GameConfig.stage)
	GameConfig.play_sfx("wave_up")

func _set_stage_bg(stage):
	$ParallaxBackground/GlacialLayer.visible = stage == GameConfig.Stage.GLACIAL
	$ParallaxBackground/DarkForestLayer.visible = stage == GameConfig.Stage.DARK_FOREST
	$ParallaxBackground/CaveLayer.visible = stage == GameConfig.Stage.CAVE

func spawn_arrow(pos, direction, speed, damage, from_hero):
	if not arrow_scene:
		return
	var arrow = arrow_scene.instantiate()
	arrow.global_position = pos
	arrow.direction = direction
	arrow.speed = speed
	arrow.damage = damage
	arrow.from_hero = from_hero
	$World.add_child(arrow)

func _on_hero_died():
	GameConfig.play_sfx("game_over")
	shake_camera(12)
	GameConfig.update_records(int(hero.position.x / 35))
	GameConfig.gain_bounce_progress()
	hero.max_hp = minf(150, hero.max_hp + 5)
	hero.hp = hero.max_hp
	_show_message("RESTARTED! RANK %d" % GameConfig.bounce_count)
	await get_tree().create_timer(1.0).timeout

	for enemy in get_tree().get_nodes_in_group("enemy"):
		if not enemy.is_stage_boss and enemy.global_position.distance_to(hero.global_position) < 300:
			enemy.queue_free()

	hero.global_position = Vector2(hero.position.x - 90, 840)
	hero.bounce_back()

func _show_message(message):
	curtain.show()
	stage_text.text = message
	curtain.modulate.a = 0
	stage_text.modulate.a = 0
	var tween = create_tween()
	tween.tween_property(curtain, "modulate:a", 1, 0.2)
	tween.parallel().tween_property(stage_text, "modulate:a", 1, 0.2)
	tween.tween_interval(1.0)
	tween.tween_property(curtain, "modulate:a", 0, 0.3)
	tween.parallel().tween_property(stage_text, "modulate:a", 0, 0.3)
	tween.tween_callback(curtain.hide)

func _build_pause():
	pause_layer = CanvasLayer.new()
	pause_layer.layer = 20
	pause_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	pause_layer.hide()
	add_child(pause_layer)

	var panel = PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.position = Vector2(-150, -90)
	panel.custom_minimum_size = Vector2(300, 180)
	pause_layer.add_child(panel)

	var buttons = VBoxContainer.new()
	panel.add_child(buttons)
	for item in [["LANJUTKAN", _toggle_pause], ["ULANGI", _retry], ["MENU UTAMA", _menu]]:
		var button = Button.new()
		button.text = item[0]
		button.custom_minimum_size.y = 42
		button.pressed.connect(item[1])
		buttons.add_child(button)

func _toggle_pause():
	get_tree().paused = not get_tree().paused
	pause_layer.visible = get_tree().paused
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if get_tree().paused else Input.MOUSE_MODE_HIDDEN

func _retry():
	get_tree().paused = false
	Engine.time_scale = 1
	get_tree().reload_current_scene()

func _menu():
	get_tree().paused = false
	Engine.time_scale = 1
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().change_scene_to_file("res://scenes/start_screen.tscn")
