extends Control
class_name GameOverUI
signal retry_requested
signal menu_requested
@onready var title_label: Label = $CenterContainer/VBoxContainer/BigGameOverTitle
@onready var stats_label: Label = $CenterContainer/VBoxContainer/StatsLabel
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	hide()
func show_result(title: String, details: String) -> void:
	title_label.text = title
	stats_label.text = details
	show()
func _on_retry_pressed() -> void:
	retry_requested.emit()
func _on_menu_pressed() -> void:
	menu_requested.emit()
