extends Control
class_name WaveBannerUI
@onready var title_label: Label = $Strip/VBoxContainer/WaveTitle
@onready var subtitle_label: Label = $Strip/VBoxContainer/WaveSubtitle
func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	hide()
func show_wave(number: int, enemy_count: int) -> void:
	title_label.text = "WAVE %d" % number
	subtitle_label.text = "MONSTER MENYERANG!!!, Sebanyak•  %d Monster mengarah ke u!" % enemy_count
	show()
	modulate.a = 0.0
	var tween := create_tween()
	tween.tween_property(self, "modulate:a", 1.0, 0.25)
	tween.tween_interval(0.85)
	tween.tween_property(self, "modulate:a", 0.0, 0.35)
	tween.tween_callback(hide)
