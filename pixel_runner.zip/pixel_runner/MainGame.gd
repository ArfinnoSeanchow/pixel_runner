extends Node2D

# --- PENGATURAN MUDAH (Bisa langsung diedit di panel Inspector) ---
@export var kecepatan_pemain = 300.0
@export var kecepatan_panah = 650.0
@export var gambar_panah: Texture2D = preload("res://assets/arrow/arrow.png")
@export var gambar_monster: Texture2D = preload("res://assets/bosses/boss_goblin.png")

# --- VARIABEL GAME ---
var wave = 1
var skor = 0
var monster_tersisa = 3
var game_selesai = false

var daftar_panah = []
var daftar_monster = []

@onready var player = $Player
@onready var bow_point = $Player/BowPoint
@onready var wave_label = $UI/WaveLabel
@onready var score_label = $UI/ScoreLabel
@onready var game_over_label = $UI/GameOverLabel

func _ready():
	game_over_label.visible = false
	update_tampilan()

func _physics_process(delta):
	if game_selesai:
		# Tekan Spasi / Enter untuk main lagi jika kalah
		if Input.is_action_just_pressed("ui_accept"):
			get_tree().reload_current_scene()
		return

	# 1. GERAKAN PEMAIN (Panah Kiri & Kanan)
	var arah = Input.get_axis("ui_left", "ui_right")
	player.velocity.x = arah * kecepatan_pemain
	player.velocity.y += 980 * delta # Gravitasi sederhana
	
	# Balik arah gambar karakter saat jalan ke kiri/kanan
	if arah != 0:
		player.get_node("Sprite2D").flip_h = (arah < 0)
		
	player.move_and_slide()

	# 2. TEMBAK PANAH (Tekan Spasi / Enter)
	if Input.is_action_just_pressed("ui_accept"):
		tembak_panah()

	# 3. GERAKKAN SEMUA PANAH & CEK TABRAKAN
	for panah in daftar_panah.duplicate():
		panah.position.x += panah.get_meta("arah") * kecepatan_panah * delta
		
		# Hapus panah jika keluar layar
		if panah.position.x < -50 or panah.position.x > 1250:
			daftar_panah.erase(panah)
			panah.queue_free()
			continue
			
		# Cek apakah panah mengenai monster
		for monster in daftar_monster.duplicate():
			if panah.position.distance_to(monster.position) < 55:
				skor += 10
				update_tampilan()
				
				daftar_panah.erase(panah)
				panah.queue_free()
				
				daftar_monster.erase(monster)
				monster.queue_free()
				break

	# 4. GERAKKAN MONSTER MENGEJAR PEMAIN
	for monster in daftar_monster.duplicate():
		var arah_ke_pemain = sign(player.position.x - monster.position.x)
		monster.position.x += arah_ke_pemain * (90 + wave * 15) * delta
		monster.flip_h = (arah_ke_pemain < 0)
		
		# Jika monster menyentuh pemain -> Game Over
		if monster.position.distance_to(player.position) < 45:
			game_selesai = true
			game_over_label.visible = true

	# 5. CEK APAKAH WAVE SELESAI -> LANJUT WAVE BERIKUTNYA
	if monster_tersisa == 0 and daftar_monster.is_empty():
		wave += 1
		monster_tersisa = wave + 2
		update_tampilan()

# --- FUNGSI MEMUNCULKAN PANAH ---
func tembak_panah():
	var panah = Sprite2D.new()
	panah.texture = gambar_panah
	panah.scale = Vector2(2, 2)
	panah.position = bow_point.global_position
	
	var hadap_kiri = player.get_node("Sprite2D").flip_h
	panah.flip_h = hadap_kiri
	panah.set_meta("arah", -1 if hadap_kiri else 1)
	
	add_child(panah)
	daftar_panah.append(panah)

# --- FUNGSI MEMUNCULKAN MONSTER PER WAVE ---
func _on_wave_timer_timeout():
	if game_selesai or monster_tersisa <= 0:
		return
		
	var monster = Sprite2D.new()
	monster.texture = gambar_monster
	monster.scale = Vector2(2, 2)
	
	# Muncul acak dari ujung kiri atau ujung kanan layar
	var dari_kiri = randf() > 0.5
	monster.position = Vector2(40 if dari_kiri else 1110, player.position.y)
	
	add_child(monster)
	daftar_monster.append(monster)
	monster_tersisa -= 1

func update_tampilan():
	wave_label.text = "Wave: " + str(wave)
	score_label.text = "Skor: " + str(skor)
